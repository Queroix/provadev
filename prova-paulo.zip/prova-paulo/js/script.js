$('.limpar').click(function () {
    $('#value_a').val('');
    $('#value_b').val('');
    $('#value_c').val('');
});


$('.calcular').click(function () {
    var a = $('#value_a').val();
    var b = $('#value_b').val();
    var c = $('#value_c').val();

    var x1;
    var x2;

    var delta = (b * b) - 4 * a * c;
    console.log('Delta: ' + delta);

    if (delta < 0) {
        console.log('Para Delta negativo, não existem raízes reais. <br/>');
        console.log('O resultado da equação de segundo grau - é indeterminado.')
    } else {

        console.log('Para Delta positivo, raízes diferentes: <br/>');

        x1 = (-b + Math.sqrt(delta)) / (2 * a);
        x2 = (-b - Math.sqrt(delta)) / (2 * a);

        console.log('O resultado da equação de segundo grau - é x1 = x1 e x2 = x2.')
    }


    if (a == 0) { a = ""; }
    else { a = a + "x²"; }

    if (b == 0) { b = ""; }
    else if (b > 0) { b = " + " + b + "x"; }
    else if (b < 0) { b = " - " + (b * -1) + "x"; }

    if (c == 0) { c = ""; }
    else if (c > 0) { c = " + " + c; }
    else if (c < 0) { c = " - " + (c * -1); }

    var x1a = parseFloat(x1.toFixed(2)); //arrendondado caso de com virgula
    var x2a = parseFloat(x2.toFixed(2));


    var resultado = "O resultado da equação do segundo grau " + a + b + c + " = 0 é x' = " + x1a + " e x'' = " + x2a;

    $('.resultado').text(resultado);

});